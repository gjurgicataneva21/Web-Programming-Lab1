//package mk.ukim.finki.wp.lab.repository.impl;
//
//import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
//import mk.ukim.finki.wp.lab.model.Chef;
//import mk.ukim.finki.wp.lab.model.Dish;
//import mk.ukim.finki.wp.lab.repository.ChefRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Repository
//public class InMemoryChefRepository implements ChefRepository {
//
//    @Override
//    public List<Chef> findAll() {
//        return DataHolder.chefs;
//    }
//
//    @Override
//    public Optional<Chef> findById(Long id) {
//        return DataHolder.chefs.stream()
//                .filter(chef -> chef.getId().equals(id))
//                .findFirst();
//    }
//
//    @Override
//    public Chef save(Chef chef) {
//        DataHolder.chefs.removeIf(c-> c.getId().equals(chef.getId()));
//        DataHolder.chefs.add(chef);
//        return chef;
//    }
//
//    @Override
//    public void deleteDishFromChef(Chef chef, String dishId) {
//        if (chef.getDishes() != null) {
//            chef.getDishes().removeIf(dish -> dish.getDishId().equals(dishId));
//        }
//        save(chef);
//    }
//}
